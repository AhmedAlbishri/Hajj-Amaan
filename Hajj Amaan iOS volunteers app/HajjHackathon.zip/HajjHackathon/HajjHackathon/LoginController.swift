//
//  LoginController.swift
//  HajjHackathon
//
//  Created by OMAR MUSSA on 8/1/18.
//  Copyright © 2018 OMAR MUSSA. All rights reserved.
//

import UIKit
import Firebase
import FirebaseFirestore
import KRProgressHUD

class LoginController: UIViewController {

    

    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let styles: [KRProgressHUDStyle] = [.white, .black, .custom(background: #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1), text: #colorLiteral(red: 0.1294117719, green: 0.2156862766, blue: 0.06666667014, alpha: 1), icon: #colorLiteral(red: 0.1294117719, green: 0.2156862766, blue: 0.06666667014, alpha: 1))]
        KRProgressHUD.set(style: styles[1])
        
        self.title = "Hajj Amaan"
    }

    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var username: UITextField!
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        let defaults = UserDefaults.standard
        let user = defaults.string(forKey: "username")
        let pass = defaults.string(forKey: "password")
        
        if username != nil && pass != nil {
            loginProcess(user: user!, pass: pass!)
        }
    }
    
    @IBAction func DoLogin(_ sender: Any) {
        
        let user = username.text!
        let pass = password.text!

        
        
        loginProcess(user: user, pass: pass)
            
        
        

    
    }
    
    @objc func loginProcess(user:String, pass:String){
        
        //KRProgressHUD.show()
        
        //KRProgressHUD.
        KRProgressHUD.show(withMessage: "Loading...")

        
        
        let db = Firestore.firestore()
        // Do any additional setup after loading the view.
        
        // Create a reference to the cities collection
        let usersRef = db.collection("Users")
        //usersRef.whereField("username", isEqualTo: "12343")
        //usersRef.whereField("password", isEqualTo: "12345")
        
        
        //                        for usersRef in querySnapshot!.documents {
        //                            print("\(document.documentID) => \(document.data())")
        //                        }
        usersRef.whereField("username", isEqualTo: user).whereField("password", isEqualTo: pass).getDocuments() { (querySnapshot, err) in
            if let err = err {
                print("Error getting documents: \(err)")
            } else {
                KRProgressHUD.dismiss()
                if(querySnapshot!.documents.count == 1){
                    for document in querySnapshot!.documents {
                        print("\(document.documentID) => \(document.data().values[document.data().index(forKey: "fname")!])")
                        
                        let values = document.data().values
                        let user = User()
                        let defaults = UserDefaults.standard
                        
                        user.fname = values[document.data().index(forKey: "fname")!] as! String
                        user.lname = values[document.data().index(forKey: "lname")!] as! String
                        user.username = values[document.data().index(forKey: "username")!] as! String
                        user.mobile = values[document.data().index(forKey: "mobile")!] as! String
                        
                        defaults.set(values[document.data().index(forKey: "username")!], forKey: "username")
                        defaults.set(values[document.data().index(forKey: "password")!], forKey: "password")
                        
                        
                        
                        // Register Nib
                        let newViewController = MainViewController (nibName: "MainViewController", bundle: nil)
                        //newViewController.managedObjectContext = self.managedObjectContext
                        newViewController.user = user
                        
                        let addViewController = UINavigationController(rootViewController: newViewController)
                        //newViewController.setModal(modal: true)
                        
                        // Present View "Modally"
                        self.present(addViewController, animated: true, completion: nil)
                    }
                }else{
                    print("no data match!")
                    
                    let alert = UIAlertController(title: "Sorry", message: "Wrong username or password!.", preferredStyle: .alert)
                    
                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    
                    self.present(alert, animated: true)
                }
            }
        }
    }
    
//    @objc func addPointsFromLocalItems() {
//        // Register Nib
//        let newViewController = SearchLocalItemController (nibName: "SearchLocalItemController", bundle: nil)
//        //newViewController.managedObjectContext = self.managedObjectContext
//        newViewController.selectedDate = self.selectedDate
//
//        let addViewController = UINavigationController(rootViewController: newViewController)
//        newViewController.setModal(modal: true)
//
//        // Present View "Modally"
//        self.present(addViewController, animated: true, completion: nil)
//
//        // Push View
//        //navigationController?.pushViewController(newViewController, animated: true)
//    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
