//
//  requestTVController.swift
//  HajjHackathon
//
//  Created by OMAR MUSSA on 8/1/18.
//  Copyright © 2018 OMAR MUSSA. All rights reserved.
//

import UIKit
import RSSelectionMenu
import Firebase
import FirebaseFirestore
import FirebaseStorage

import KRProgressHUD
import CoreLocation
import MapKit

class requestTVController: UITableViewController, CLLocationManagerDelegate {
    
    var user: User?
    
    //this will contains the sections cells
    var section1: [UITableViewCell] = []
    var section2: [UITableViewCell] = []
    var section3: [UITableViewCell] = []
    var section4: [UITableViewCell] = []
    var section5: [UITableViewCell] = []

    //the cell data
    var sections: [[UITableViewCell]] = []
    
    
    @IBOutlet var typeCell: UITableViewCell!
    @IBOutlet var descCell: UITableViewCell!
    @IBOutlet var imageCell: UITableViewCell!

    @IBOutlet var locCell: UITableViewCell!
    
    @IBOutlet var importanceCell: UITableViewCell!
    @IBOutlet var footer: UIView!
    @IBOutlet weak var imageStatusLabel: UILabel!
    @IBOutlet weak var descTextView: UITextView!
    
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var importanceSegment: UISegmentedControl!
    var issuesTypeArray = [String]()
    var issuesTypeIndexes = [String]()
    
    var issuesTypeArraySelected = [String]()
    var issuesTypeArraySelectedIndex:Int?
    
    var userLocation : CLLocationCoordinate2D?
    var locationManager = CLLocationManager()
    
    // data for captured image
    var imagePicker:UIImagePickerController!

    var imageData:Data?
    
    // dispatch queues
    let convertQueue = DispatchQueue(label: "convertQueue", attributes: .concurrent)
    let saveQueue = DispatchQueue(label: "saveQueue", attributes: .concurrent)

   // @IBOutlet weak var longLabel: UILabel!
    //@IBOutlet weak var latLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        let styles: [KRProgressHUDStyle] = [.white, .black, .custom(background: #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1), text: #colorLiteral(red: 0.1294117719, green: 0.2156862766, blue: 0.06666667014, alpha: 1), icon: #colorLiteral(red: 0.1294117719, green: 0.2156862766, blue: 0.06666667014, alpha: 1))]
        KRProgressHUD.set(style: styles[1])
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        
        if CLLocationManager.locationServicesEnabled(){
            locationManager.requestAlwaysAuthorization()
        }
        
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.delegate = self
        
        self.section1 = [typeCell]
        self.section2 = [importanceCell]
        self.section3 = [descCell]
        self.section4 = [imageCell]
        self.section5 = [locCell]

        sections = [section1, section2, section3, section4, section5]
        
        self.tableView.tableFooterView = footer
        
        locationManager.startUpdatingLocation()
        
        loadIssuesList()
        
        //let loc = getUserLocation()
        self.title = "New Request"
        //print("\(String(describing: loc?.coordinate.longitude))")
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        
        
    }
    
    
    func getUserLocation() ->  CLLocation?{
        if userLocation == nil{
            return nil
        }
        
        
        return CLLocation(latitude: (userLocation?.latitude)!, longitude: (userLocation?.longitude)!)
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations.last
        let center = CLLocationCoordinate2D(latitude: (location?.coordinate.latitude)!, longitude: (location?.coordinate.longitude)!)
        let mkCoordinateRegion = MKCoordinateRegionMakeWithDistance(center, CLLocationDistance(200), CLLocationDistance(200))
        
        mapView.setRegion(mkCoordinateRegion, animated: true)

        print("loc \(String(describing: location?.coordinate.longitude))")
        //latLabel.text = "r"
        userLocation = location?.coordinate
        if userLocation?.latitude != nil {
            //latLabel.text = String(format: "%f", (location?.coordinate.latitude)!)
            //longLabel.text = String(format: "%f", (location?.coordinate.longitude)!)
            locationManager.stopUpdatingLocation()
        }
        
        
        
        
        //let mkCoordinateRegion = MKCoordinateRegionMakeWithDistance(center, CLLocationDistance(zoomDistance), CLLocationDistance(zoomDistance))
        
        //mapView.setRegion(mkCoordinateRegion, animated: true)
    }
    
    @objc func loadIssuesList(){
        KRProgressHUD.show(withMessage: "Loading...")
        let db = Firestore.firestore()
        // Do any additional setup after loading the view.
        
        // Create a reference to the cities collection
        let usersRef = db.collection("IssuesTypes")
        //usersRef.whereField("username", isEqualTo: "12343")
        //usersRef.whereField("password", isEqualTo: "12345")
        
        
        //                        for usersRef in querySnapshot!.documents {
        //                            print("\(document.documentID) => \(document.data())")
        //                        }
        usersRef.getDocuments() { (querySnapshot, err) in
            if let err = err {
                print("Error getting documents: \(err)")
            } else {
                if(querySnapshot!.documents.count > 0){
                    for document in querySnapshot!.documents {
                        print("\(document.documentID) => \(document.data().values[document.data().index(forKey: "name")!])")
                        
                        self.issuesTypeArray.append(document.data().values[document.data().index(forKey: "name")!] as! String)
                        
                            self.issuesTypeIndexes.append(document.documentID)
                        //print("\(document.documentID)")
  
                    }
                }else{
                    
                    let alert = UIAlertController(title: "Error", message: "No data was loaded.", preferredStyle: .alert)
                    
                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    
                    self.present(alert, animated: true)
                }
            }
            KRProgressHUD.dismiss()
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return sections.count
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sections[section].count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        let cell = sections[indexPath.section][indexPath.row]

        return cell
    }
 
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch indexPath.section {
        case 1:
            return 87.0
        case 2:
            return 134.0
        case 4:
            return 177.0
        default:
            return 44.0
        }
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        switch indexPath.section {
        case 0:
            //let simpleDataArray = ["Sachin", "Rahul", "Saurav", "Virat", "Suresh", "Ravindra", "Chris"]
            //var simpleSelectedArray = [String]()
            
            // Show menu with datasource array - Default SelectionType = Single
            // Here you'll get cell configuration where you can set any text based on condition
            // Cell configuration following parameters.
            // 1. UITableViewCell   2. Object of type T   3. IndexPath
            
            let selectionMenu =  RSSelectionMenu(dataSource: issuesTypeArray) { (cell, object, indexPath) in
                cell.textLabel?.text = object
                
                // Change tint color (if needed)
                cell.tintColor = .orange
            }
            
            // set default selected items when menu present on screen.
            // Here you'll get onDidSelectRow
            
            selectionMenu.setSelectedItems(items: issuesTypeArraySelected) { (text, isSelected, selectedItems) in
                
                // update your existing array with updated selected items, so when menu presents second time updated items will be default selected.
                //self.simpleSelectedArray = selectedItems
                self.issuesTypeArraySelectedIndex = self.issuesTypeArray.index(of: selectedItems[0])
                
                self.typeCell.detailTextLabel?.text = selectedItems[0]//---here
            }
            
            selectionMenu.showSearchBar(withPlaceHolder: "Search", tintColor: UIColor.lightGray) { (searchtext) -> ([String]) in
                return self.issuesTypeArray.filter({ $0.lowercased().hasPrefix(searchtext.lowercased()) })
            }
            
            
            
            // show as PresentationStyle = Push
            selectionMenu.show(style: .Formsheet, from: self)//.show(style: .Push, from: self)
        case 3:
            imagePickerSetup() // image picker delegate and settings
            self.present(imagePicker, animated: true, completion: nil)
        default: break
            
        }
        
        //[tableView deselectRowAtIndexPath:indexPath animated:YES];
        tableView.deselectRow(at: indexPath, animated: true)
    }

    @IBAction func saveRequestToCloud(_ sender: Any) {
        
        if issuesTypeArraySelectedIndex == nil {
            
            KRProgressHUD.showInfo(withMessage: "Please choose the issue type first.")
            
            return
        }
        
        var imagePath = ""
        
        if imageData != nil {
            print("start uploading..")
            KRProgressHUD.show(withMessage: "Uploading Image...")
            // Get a reference to the storage service using the default Firebase App
            let storage = Storage.storage()
            
            // Create a storage reference from our storage service
            let storageRef = storage.reference()
            
            // Create a reference to the file you want to upload
            let timestamp = NSDate().timeIntervalSince1970

            let rand = Int(arc4random_uniform(100000))
             imagePath = "issues/\(rand).\(timestamp.description).jpg"
            let imageRef = storageRef.child(imagePath)
            
            // Upload the file to the path "images/rivers.jpg"
            let uploadTask = imageRef.putData(imageData!, metadata: nil) { (metadata, error) in
                guard let metadata = metadata else {
                    // Uh-oh, an error occurred!
                    print("upload error..")
                    return
                }
                // Metadata contains file metadata such as size, content-type.
                let size = metadata.size
                // You can also access to download URL after upload.
                imageRef.downloadURL { (url, error) in
                    guard let downloadURL = url else {
                        // Uh-oh, an error occurred!
                        print("upload error..")
                        return
                    }
                }
                print("upload done..")
                
                
            }
        }
        
        KRProgressHUD.show(withMessage: "Creating issue...")
        
        let db = Firestore.firestore()
        // Add a new document in collection "cities"
        db.collection("IssuesList").document().setData([
            "assigned_to": "",
            "created_by": self.user?.username,
            "description": self.descTextView.text!,
            "importance": self.importanceSegment.selectedSegmentIndex,
            "location": GeoPoint(latitude: (self.userLocation?.latitude)!, longitude: (self.userLocation?.longitude)!),
            "issue_type_id": self.issuesTypeIndexes[self.issuesTypeArraySelectedIndex!],
            "picture": imagePath,
            "status": "Open",
            "time": Timestamp(date: Date())
        ]) { err in
            if let err = err {
                print("Error writing document: \(err)")
                KRProgressHUD.showError(withMessage: "An error happend. Please try again..")
                DispatchQueue.main.asyncAfter(deadline: .now()+3) {
                    KRProgressHUD.dismiss()
                }
            } else {
                print("Document successfully written!")
                
                DispatchQueue.main.asyncAfter(deadline: .now()) {
                    self.navigationController?.popViewController(animated: true)
                        KRProgressHUD.showSuccess(withMessage: "Your request was successfully submitted.")
                    
                    
                }
            }
        }
        
        
        
    }
    
    override func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {

            return CGFloat.leastNormalMagnitude
        
    }
   
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
}

extension requestTVController : UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    @objc func imagePickerSetup() {
        if(imagePicker == nil){
            imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerControllerSourceType.camera
            imagePicker.allowsEditing = false
        }
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        DispatchQueue.main.async {
           // self.spinner.stopAnimating()
        }
        self.dismiss(animated: true, completion: nil)
    }
    
    // When an image is "picked" it will return through this function
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        DispatchQueue.main.async {
            //self.spinner.startAnimating()
        }
        self.dismiss(animated: true, completion: nil)
        if let pickerImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            prepareImageForSaving(image: pickerImage)
        }
    }
    
    
    func prepareImageForSaving(image:UIImage) {
        
        // use date as unique id
        let date : Double = NSDate().timeIntervalSince1970
        
        // dispatch with gcd.
        convertQueue.async {
            
            // create NSData from UIImage
            guard let imageData = UIImageJPEGRepresentation(image, 1) else {
                // handle failed conversion
                print("jpg error")
                DispatchQueue.main.async {
                   // self.spinner.stopAnimating()
                }
                return
            }
            
            // scale image to the size of the VC because it is easy
            let thumbnail = image.scale(toSize: self.view.frame.size)

            guard let thumbnailData  = UIImageJPEGRepresentation(thumbnail, 0.7) else {
                // handle failed conversion
                print("jpg error")
                DispatchQueue.main.async {
                    //self.spinner.stopAnimating()
                }
                return
            }
            
            // send to save function
            self.saveImage(imageData: imageData, thumbnailData: thumbnailData, date: date)
        }
    }
    
    func saveImage(imageData:Data, thumbnailData:Data, date: Double) {
        saveQueue.sync {
            DispatchQueue.main.async {
                //let image = UIImage(data: imageData)
                //self.imageView.image = image
                //self.spinner.stopAnimating()
                
                self.imageData = thumbnailData
                self.imageStatusLabel.text = "Ready, click to replace."
            }
        }
    }
}

extension UIImage {
    
    func scale(toSize newSize:CGSize) -> UIImage {
        
        // make sure the new size has the correct aspect ratio
        let aspectFill = self.size.resizeFill(toSize: newSize)
        
        UIGraphicsBeginImageContextWithOptions(aspectFill, false, 0.0);
        self.draw(in: CGRect(origin: .zero, size: CGSize(width: aspectFill.width, height: aspectFill.height)))
        let newImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        return newImage
    }
    
}

extension CGSize {
    
    func resizeFill(toSize: CGSize) -> CGSize {
        
        let scale : CGFloat = (self.height / self.width) < (toSize.height / toSize.width) ? (self.height / toSize.height) : (self.width / toSize.width)
        return CGSize(width: (self.width / scale)*0.5, height: (self.height / scale)*0.5)
        
    }
}

extension UIView {
    
    func fadeIn(duration: TimeInterval = 0.2, delay: TimeInterval = 0.0, completion: @escaping ((Bool) -> Void) = {(finished: Bool) -> Void in}) {
        UIView.animate(withDuration: duration, delay: delay, options: UIViewAnimationOptions.curveEaseIn, animations: {
            self.alpha = 1.0
        }, completion: completion)  }
    
    func fadeOut(duration: TimeInterval = 0.2, delay: TimeInterval = 0.0, completion: @escaping (Bool) -> Void = {(finished: Bool) -> Void in}) {
        UIView.animate(withDuration: duration, delay: delay, options: UIViewAnimationOptions.curveEaseIn, animations: {
            self.alpha = 0.0
        }, completion: completion)
    }
    
}
