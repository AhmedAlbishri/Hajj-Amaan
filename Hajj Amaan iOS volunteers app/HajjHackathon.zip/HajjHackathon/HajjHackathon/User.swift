//
//  User.swift
//  HajjHackathon
//
//  Created by OMAR MUSSA on 8/1/18.
//  Copyright © 2018 OMAR MUSSA. All rights reserved.
//

import Foundation

class User: NSObject {
     var username : String = ""
     var fname : String = ""
     var lname : String = ""
     var mobile : String = ""
}
